package com.example.wifiswitcher;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

//help from tutorial: https://stackoverflow.com/questions/8863509/how-to-programmatically-turn-off-wifi-on-android-device

public class MainActivity extends AppCompatActivity {
    Timer t = new Timer();
    TextView status;
    Button startButton;
    Button stopButton;
    boolean running = false;
    private WifiManager wifiManager;

    @SuppressLint("WifiManagerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        super.onCreate(savedInstanceState);
        wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE); // might cause memory leak

        setContentView(R.layout.activity_main);

        stopButton = findViewById(R.id.stopButton);
        stopButton.setOnClickListener(onClickStopListener);

        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(onClickStartListener);


        status = findViewById(R.id.status);
        status.setText(getString(R.string.notrunning));
        System.out.println("BBBBBBBBBBBBBBBBBBBBBBBBB");
    }

    Button.OnClickListener onClickStopListener = new Button.OnClickListener() { // stop button
        @Override
        public void onClick(View view) {
            System.out.println("STOP");
            status.setText(getString(R.string.notrunning));
            running = false;
            stop();
        }
    };
    Button.OnClickListener onClickStartListener = new Button.OnClickListener() { // stop button
        @Override
        public void onClick(View view) {
            System.out.println("START");
            status.setText(getString(R.string.running));
            running = true;
            start();
        }
    };

    public void cancelAndPurge(){
        t.cancel();
        t.purge();
    }

    public void start() {
        cancelAndPurge();
        TimerTask runFlipper = new TimerTask() {
            @Override
            public void run() {
                switchOnAndOff();
                System.out.println(System.currentTimeMillis());
            }
        };
        t = new Timer();
        t.scheduleAtFixedRate(runFlipper, 0, 50);
    }

    public void stop() {
        cancelAndPurge();
    }

    public void switchOnAndOff() {
        wifiManager.setWifiEnabled(false);
        try {
            wait(100); // wait for 100 ms
        } catch (Exception e) {
            System.err.println(e);
        }
        wifiManager.setWifiEnabled(true);
    }
}
